package org.example;

import java.util.Locale;

public class Auditorio extends Salas {
    public Auditorio(int id, String local, String name, int capacidade) {
        super(id, local, name, capacidade);
    }

    Mesas[] MesasAuditorio = new Mesas[] {};

    public static void main(String[] args){

    }
}

