package org.example;

import java.util.Locale;


public class Reuniao extends Salas {
    public Reuniao(int id, String local, String name, int capacidade) {
        super(id, local, name, capacidade);
    }

     Mesas[] MesasReuniao = new Mesas[] {};

    public static void main(String[] args){




    }
}