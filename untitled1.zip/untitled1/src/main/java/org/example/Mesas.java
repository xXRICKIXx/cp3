package org.example;


public class Mesas extends Salas {
    public Mesas(int id, String local, String name, int capacidade) {
        super(id, local, name, capacidade);
    }


}
